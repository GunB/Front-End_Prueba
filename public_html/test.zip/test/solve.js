// Put the code here to solve the Game
function init() {
	Game.start();
	var first_word = Game.start();
}